package com.example.bdsuper.Vista;

public interface Interface_RestablecerContra {
    void mostrarPregunta(String pregunta);
    void mostrarError(String error);

}
