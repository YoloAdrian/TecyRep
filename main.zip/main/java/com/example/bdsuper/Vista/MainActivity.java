package com.example.bdsuper.Vista;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.bdsuper.Presentador.Interface_PresentadorL;
import com.example.bdsuper.Presentador.Presentador_Login;
import com.example.bdsuper.R;

public class MainActivity extends AppCompatActivity implements Interface_Login{

    EditText txtusuario;
    EditText txtpassword;
    Button btnAcceso;

    Button  btnRecuperar;
    Interface_PresentadorL P;
    public static Context contexto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtusuario=(EditText) findViewById(R.id.txtusuario);
        txtpassword=(EditText) findViewById(R.id.txtpassword);
        btnAcceso=(Button) findViewById(R.id.btnAcceso);
        btnRecuperar=(Button) findViewById(R.id.btnRecuperar);
        btnAcceso.setOnClickListener(this::eventoAcceder);

        P=new Presentador_Login(this);
        contexto=this;

        btnRecuperar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RestablecerContra.class);
                startActivity(intent);
            }
        });

    }
    public void eventoAcceder(View vi)
    {
      // Toast.makeText(this,txtusuario.getText().toString()+" "+txtpassword.getText().toString(),Toast.LENGTH_LONG).show();
        P.login(txtusuario.getText().toString(),txtpassword.getText().toString());
    }

    @Override
    public void acceso(String miusuario, String foto) {
        if(!(miusuario.trim().isEmpty()==true))
        {
            //Toast.makeText(this,"Encontrado..."+ miusuario,Toast.LENGTH_LONG).show();

            Intent vista2=new Intent(this,Principal.class);
            vista2.putExtra("usuario",miusuario);
            vista2.putExtra("foto",foto);
            startActivity(vista2);
        }
    }
}