package com.example.bdsuper.Vista;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bdsuper.R;
import com.squareup.picasso.Picasso;

public class Detalles extends AppCompatActivity {
    ImageView imgProducto;
    TextView txtProducto;
    TextView txtDescripcion;
    TextView txtPProducto;
    TextView txtExistencias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detalles);
        imgProducto = (ImageView) findViewById(R.id.imgProducto);
        txtProducto = (TextView) findViewById(R.id.txtProducto);
        txtDescripcion = (TextView) findViewById(R.id.txtDescripcion);
        txtPProducto = (TextView) findViewById(R.id.txtPProducto);
        txtExistencias = (TextView) findViewById(R.id.txtExistencias);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String nombre = extras.getString("nombre");
            String precio = extras.getString("precio");
            String existencia = extras.getString("existencia");
            String foto = extras.getString("foto");
            String descripcion = extras.getString("descripcion");

            txtProducto.setText(nombre);
            txtPProducto.setText(precio);
            txtExistencias.setText(existencia);
            txtDescripcion.setText(descripcion);
            Picasso.get().load("http://189.240.192.140/TecyRep20221309/imagenes/" + foto).resize(350, 350).centerCrop().into(imgProducto);
        }
    }

}
