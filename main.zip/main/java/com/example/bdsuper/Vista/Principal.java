package com.example.bdsuper.Vista;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.bdsuper.Modelo.Adaptador;
import com.example.bdsuper.Modelo.ClaseDatosProductos;
import com.example.bdsuper.Presentador.Presentador_ListaProductos;
import com.example.bdsuper.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Locale;

public class Principal extends AppCompatActivity {
    TextView txtUsuario;
    ImageView imgFoto;
    RecyclerView rcvlista;
    //para poder buscar
    EditText txtBuscar;
    Button btnBuscar;

    //hasta aqui
    public static Context VistaPrincipal;
    Presentador_ListaProductos P;
    //esto es parte de buscar


    ArrayList<ClaseDatosProductos> productos;
    private Adaptador adaptador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        txtUsuario=(TextView) findViewById(R.id.txtUsuario);
        imgFoto=(ImageView) findViewById(R.id.imgFoto);
        rcvlista =(RecyclerView) findViewById(R.id.rcvlista);
        rcvlista.setLayoutManager(new GridLayoutManager(this,1));
        //esto es de la parte de buscar
        txtBuscar=(EditText) findViewById(R.id.txtBuscar);
        btnBuscar=(Button) findViewById(R.id.btnBuscar);
        btnBuscar.setOnClickListener(this::buscar);
        Bundle parametros=getIntent().getExtras();
        String dato=parametros.getString("usuario");
        String foto=parametros.getString("foto");
        txtUsuario.setText("Bienvenid@:  "+dato);
        Picasso.get().load("http://189.240.192.140/TecyRep20221309/imagenes/"+foto).resize(250,250).centerCrop().into(imgFoto);
        VistaPrincipal = this;
        P = new Presentador_ListaProductos(this);
        //detalles


    }
    public void buscar(View vi){
        String busqueda = txtBuscar.getText().toString().toLowerCase();
        ArrayList<ClaseDatosProductos> filtrar = new ArrayList<>();

        for (ClaseDatosProductos nombre : productos) {

            if (nombre.getNombre().toLowerCase().contains(busqueda)) {
                filtrar.add(nombre);
            }
        }

        Adaptador Adaptadorbuscar = new Adaptador(filtrar);
        rcvlista.setAdapter(Adaptadorbuscar);

    }
    public void cargarlistaproductos(Adaptador AdaptadorRecycler){
        productos = AdaptadorRecycler.getProductos();
        rcvlista.setAdapter(AdaptadorRecycler);
    }
}