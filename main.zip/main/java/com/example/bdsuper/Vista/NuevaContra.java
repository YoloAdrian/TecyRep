package com.example.bdsuper.Vista;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.TaskStackBuilder;

import com.example.bdsuper.Presentador.Presentador_NuevaContra;
import com.example.bdsuper.R;

public class NuevaContra extends AppCompatActivity {
    EditText txtNewPass;
    EditText txtConfPasw;
    Button btnGuardar;
    TextView txtMensaje;

    Presentador_NuevaContra P;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nuevacontra);

        txtNewPass=(EditText) findViewById(R.id.txtNewPass);
        txtConfPasw=(EditText) findViewById(R.id.txtConfPasw);
        btnGuardar=(Button) findViewById(R.id.btnGuardar);
        txtMensaje=(TextView) findViewById(R.id.txtMensaje);

        P = new Presentador_NuevaContra(this);

        String correo = getIntent().getStringExtra("correo");

        btnGuardar.setOnClickListener(v -> {
            String newPass = txtNewPass.getText().toString();
            String confPass = txtConfPasw.getText().toString();

            if (newPass.equals(confPass)) {
                P.actualizarContrasena(correo, newPass);
            } else {
                txtMensaje.setText("Verifica que las contraseñas coincidan");
            }
        });
    }

    public void mostrarExito(String mensaje) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void mostrarError(String error) {
        Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
    }
}
