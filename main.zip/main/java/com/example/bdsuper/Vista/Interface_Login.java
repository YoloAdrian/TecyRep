package com.example.bdsuper.Vista;

public interface Interface_Login {
    void acceso(String miusuario,String foto);
}
