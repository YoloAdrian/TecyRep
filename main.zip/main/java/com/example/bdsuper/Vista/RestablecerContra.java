package com.example.bdsuper.Vista;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bdsuper.Presentador.Presentador_RestablecerContra;
import com.example.bdsuper.R;

public class RestablecerContra extends AppCompatActivity implements Interface_RestablecerContra {
    EditText txtCorreo;
    TextView txtPregunta;
    TextView txtMensaje;
    EditText txtResp;
    Button btnValidar;

    TextView txtMenCorreo;
    Button btnBuscarPregunta;

    Presentador_RestablecerContra P;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.restablecercontra);
        txtCorreo =(EditText) findViewById(R.id.txtCorreo);
        txtPregunta =(TextView) findViewById(R.id.txtPregunta);
        txtMensaje =(TextView) findViewById(R.id.txtMensaje);
        txtMenCorreo =(TextView) findViewById(R.id.txtMenCorreo);
        txtResp =(EditText) findViewById(R.id.txtResp);
        btnValidar =(Button) findViewById(R.id.btnValidar);
        btnBuscarPregunta =(Button) findViewById(R.id.btnBuscarPregunta);

        P = new Presentador_RestablecerContra(this);
        btnBuscarPregunta.setOnClickListener(this::eventoBuscar);

        btnValidar.setOnClickListener(v -> {
            String correo = txtCorreo.getText().toString();
            String respuesta = txtResp.getText().toString();
            P.validarRespuesta(correo, respuesta);
        });


    }

    private void eventoBuscar(View vista) {
        P.obtenerPregunta(txtCorreo.getText().toString());
    }

    @Override
    public void mostrarPregunta(String pregunta) {
        txtPregunta.setText(pregunta);
    }

    public void irANuevaContra() {
        String correo = txtCorreo.getText().toString();
        Intent intent = new Intent(this, NuevaContra.class);
        intent.putExtra("correo", correo);
        startActivity(intent);
    }

    public void mostrarError(String error) {
        txtMensaje.setText("Verifica nuevamente la respuesta");
    }

}
