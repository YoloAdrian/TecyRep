package com.example.bdsuper.Modelo;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdsuper.Presentador.Presentador_NuevaContra;
import com.example.bdsuper.Vista.MainActivity;

import java.util.HashMap;
import java.util.Map;

public class ModeloNuevaContra implements InterfaceModelo_NC{

    Presentador_NuevaContra P;

    public ModeloNuevaContra(Presentador_NuevaContra P) {
        this.P = P;
    }
    @Override
    public void actualizarContrasenaM(String correo, String nuevaContrasena) {
        String URL = "http://189.240.192.140/TecyRep20221309/restablecerContra.php";
        StringRequest request = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (response.contains("Contraseña actualizada correctamente.")) {
                    P.contrasenaActualizada();
                } else {
                    P.errorAlActualizar(response);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                P.errorAlActualizar(error.toString());
            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros = new HashMap<>();
                parametros.put("correo", correo);
                parametros.put("nuevaContrasena", nuevaContrasena);
                return parametros;
            }
        };

        RequestQueue envio = Volley.newRequestQueue(MainActivity.contexto);
        envio.add(request);
    }

}

