package com.example.bdsuper.Modelo;

public class ClaseDatosProductos {
    String nombre;
    String imgproducto;
    String precio;
    String stock;
    String descripcion;

    public ClaseDatosProductos(String nombre, String precio,String stock, String imgproducto, String descripcion){
        this.nombre=nombre;
        this.imgproducto=imgproducto;
        this.precio=precio;
        this.stock=stock;
        this.descripcion=descripcion;
    }
    public String getNombre(){
        return nombre;
    }

    public String getDescripcion(){
        return descripcion;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public String getFoto(){
        return  imgproducto;
    }
    public void setFoto(String imgproducto){
        this.imgproducto = imgproducto;
    }
    public String getPrecio(){
        return precio;
    }
    public void setPrecio(String precio){
        this.precio=precio;
    }
    public String getExistencia(){
        return stock;
    }
    public void setExistencia(String stock){
        this.stock =stock;
    }
}
