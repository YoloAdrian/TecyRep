package com.example.bdsuper.Modelo;

public interface InterfaceModelo_NC {
    void actualizarContrasenaM(String correo, String nuevaContrasena);
}
