package com.example.bdsuper.Modelo;

public interface Interface_Listaproductos {
    void MostrarLista();
}
