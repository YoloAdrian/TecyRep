package com.example.bdsuper.Modelo;

public interface InterfaceModelo_RC {
    void obtenerPreguntaM(String correo);
    void validarRespuesta(String correo, String respuesta);
}
