package com.example.bdsuper.Modelo;

import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdsuper.Presentador.Presentador_Login;
import com.example.bdsuper.Vista.MainActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Modelo_Login implements Interface_ModeloL {
    Presentador_Login P;
    String noUser, pasw;
    String datoUsuarioEncontrado;
    String foto;

    public Modelo_Login(Presentador_Login P)
    {
        this.P=P;

    }
    @Override
    public void loginM(String usuarioM, String passM) {
        //Toast.makeText(MainActivity.contexto,usuarioM+" "+passM+" Modelo",Toast.LENGTH_LONG).show();
        this.noUser=usuarioM;
        this.pasw=passM;
        consultaM(noUser,passM);

    }

    @Override
    public void consultaM(String nomUser, String pasM) {
        {//inicio metodo
            String URL="http://189.240.192.140/TecyRep20221309/login.php";
            StringRequest respuesta= new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    try{
                        JSONArray datos=new JSONArray(response);
                        for(int x=0;x<datos.length();x++)
                        {
                            JSONObject valores= datos.getJSONObject(x);
                            datoUsuarioEncontrado=valores.getString("vchnomuser");
                            foto=valores.getString("foto");
                        }
                        P.acceso(datoUsuarioEncontrado, foto);

                    }catch(Exception e){
                       // Toast.makeText(MainActivity.contexto, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    //Toast.makeText(MainActivity.contexto, error.getMessage(), Toast.LENGTH_LONG).show();

                }
            }
            ){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> parametros = new HashMap<>();
                    parametros.put("usuario",nomUser);
                    parametros.put("password", pasw);
                    return parametros;
                }
            };

            RequestQueue envio= Volley.newRequestQueue(MainActivity.contexto);
            envio.add(respuesta);

        }//finmetodo

    }
}
