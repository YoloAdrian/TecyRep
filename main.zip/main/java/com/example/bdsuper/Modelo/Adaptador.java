package com.example.bdsuper.Modelo;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bdsuper.R;
import com.example.bdsuper.Vista.Detalles;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Adaptador extends RecyclerView.Adapter<Adaptador.VistaHolderProductos> {

    //para buscar los productos
    ArrayList<ClaseDatosProductos> productos;


    //detalles ter
    public ArrayList<ClaseDatosProductos> getProductos(){
        return productos;
    }
    //termina buscar productos

    //ver detalles OnItemClickListener listener
    public Adaptador(ArrayList<ClaseDatosProductos> productos){
        this.productos = productos;
        //detalles
    }
    @NonNull
    @Override
    public VistaHolderProductos onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View V = LayoutInflater.from(parent.getContext()).inflate(R.layout.productos,null,false);
        return new VistaHolderProductos(V);
    }

    @Override
    public void onBindViewHolder(@NonNull VistaHolderProductos holder, final int position) {
        Picasso.get().load("http://189.240.192.140/TecyRep20221309/imagenes/"+productos.get(position).getFoto()).resize(350,350).into(holder.imgProducto);
        holder.txtNombre.setText(productos.get(position).getNombre());
        holder.txtPrecio.setText(String.valueOf(productos.get(position).getPrecio()));
        holder.txtStock.setText(String.valueOf(productos.get(position).getExistencia()));

        final int finalPosition = position;
        holder.btnDetalles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context contex =v.getContext();
                Intent intent = new Intent(contex, Detalles.class);
                intent.putExtra("nombre", productos.get(finalPosition).getNombre());
                intent.putExtra("precio", productos.get(finalPosition).getPrecio());
                intent.putExtra("existencia", productos.get(finalPosition).getExistencia());
                intent.putExtra("foto", productos.get(finalPosition).getFoto());
                intent.putExtra("descripcion",productos.get(finalPosition).getDescripcion());
                contex.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return productos.size();
    }
//el static es de ver detalles
    public class VistaHolderProductos extends RecyclerView.ViewHolder{
        ImageView imgProducto;
        TextView txtNombre;
        TextView txtPrecio;
        TextView txtStock;
        Button btnDetalles;
        public VistaHolderProductos(@NonNull View itemView) {
            super(itemView);
            imgProducto=itemView.findViewById(R.id.imgproducto);
            txtNombre=itemView.findViewById(R.id.txtNombre);
            txtPrecio=itemView.findViewById(R.id.txtPrecio);
            txtStock=itemView.findViewById(R.id.txtStock);
            btnDetalles=itemView.findViewById(R.id.btnDetalles);
        }
    }
}
