package com.example.bdsuper.Modelo;

import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdsuper.Presentador.Presentador_ListaProductos;
import com.example.bdsuper.Vista.Principal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class Modelo_listaproductos implements Interface_Listaproductos{
    Presentador_ListaProductos P;
    ArrayList<ClaseDatosProductos> productos = new ArrayList<ClaseDatosProductos>();
    String URL="http://189.240.192.140/TecyRep20221309/listaproductos.php";

    public Modelo_listaproductos(Presentador_ListaProductos P){
        this.P=P;
        MostrarLista();
    }

   @Override
   public void MostrarLista(){
        StringRequest respuesta = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray datos = new JSONArray(response);
                    for (int x = 0; x < datos.length(); x++) {
                        JSONObject valores = datos.getJSONObject(x);
                        String nombre = valores.getString("nombre");
                        double precio = valores.getDouble("precio_venta");
                        int existencia = valores.getInt("existencia");
                        String imagen = valores.getString("img");
                        String descripcion=valores.getString("descripcion");
                        //para poder mostrar las etiquetas
                        String PrecioE = "Precio: $" + precio ;
                        String ExistenciasE = "Existencias: " + existencia + " piezas";
                        productos.add(new ClaseDatosProductos("Producto: " + nombre, PrecioE, ExistenciasE, imagen, descripcion));
                    }
                    Adaptador AdaptadorRecycler = new Adaptador(productos);
                    P.cargarlistaproductos(AdaptadorRecycler);
                } catch (Exception e) {
                    //Toast.makeText(Principal.VistaPrincipal, "error en la extraccion de los datos del JASON", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(Principal.VistaPrincipal, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        );
        RequestQueue envio = Volley.newRequestQueue(Principal.VistaPrincipal);
        envio.add(respuesta);
    }
}
