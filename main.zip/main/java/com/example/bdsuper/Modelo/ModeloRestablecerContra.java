package com.example.bdsuper.Modelo;

import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bdsuper.Presentador.Presentador_RestablecerContra;
import com.example.bdsuper.Vista.MainActivity;
import com.example.bdsuper.Vista.RestablecerContra;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ModeloRestablecerContra implements InterfaceModelo_RC{

    Presentador_RestablecerContra P;

    public ModeloRestablecerContra(Presentador_RestablecerContra P) {
        this.P = P;
    }
    @Override
    public void obtenerPreguntaM(String correo) {
        String URL = "http://189.240.192.140/TecyRep20221309/recuperarContra.php";
        StringRequest respuesta = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray datos = new JSONArray(response);
                    for (int x = 0; x < datos.length(); x++) {
                        JSONObject valores = datos.getJSONObject(x);
                        String pregunta = valores.getString("pregunta");
                        P.mostrarPregunta(pregunta);
                    }
                } catch (Exception e) {
                    // Manejar la excepción
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros = new HashMap<>();
                parametros.put("correo", correo);
                return parametros;
            }
        };

        RequestQueue envio = Volley.newRequestQueue(MainActivity.contexto);
        envio.add(respuesta);
    }

    @Override
    public void validarRespuesta(String correo, String respuestaUsuario) {
        String URL = "http://189.240.192.140/TecyRep20221309/recuperarContra.php";
        StringRequest respuesta = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray datos = new JSONArray(response);
                    for (int x = 0; x < datos.length(); x++) {
                        JSONObject valores = datos.getJSONObject(x);
                        String respuestaCorrecta = valores.getString("respuesta");
                        if (respuestaUsuario.equals(respuestaCorrecta)) {
                            P.respuestaCorrecta();
                        } else {
                            P.respuestaIncorrecta();
                        }
                    }
                } catch (Exception e) {
                    // Manejar la excepción
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros = new HashMap<>();
                parametros.put("correo", correo);
                return parametros;
            }
        };

        RequestQueue envio = Volley.newRequestQueue(MainActivity.contexto);
        envio.add(respuesta);
    }

}
