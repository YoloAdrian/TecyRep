package com.example.bdsuper.Modelo;

public interface Interface_ModeloL {
    void loginM(String usuarioM, String passM);
    void consultaM(String nomUser,String pasM);
}
