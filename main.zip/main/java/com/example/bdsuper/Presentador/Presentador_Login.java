package com.example.bdsuper.Presentador;

import android.widget.Toast;

import com.example.bdsuper.Modelo.Interface_ModeloL;
import com.example.bdsuper.Modelo.Modelo_Login;
import com.example.bdsuper.Vista.MainActivity;

public class Presentador_Login implements Interface_PresentadorL {
    MainActivity V;
    Interface_ModeloL M;

    public Presentador_Login(MainActivity V) {
        this.V=V;
        M = new Modelo_Login(this);
    }

    @Override
    public void login(String usuario, String pass) {
        //Toast.makeText(MainActivity.contexto,usuario+" "+pass+" Presentador",Toast.LENGTH_LONG).show();
        M.loginM(usuario,pass);
    }

    @Override
    public void acceso(String miusuario,String foto) {
        V.acceso(miusuario,foto);
    }
}
