package com.example.bdsuper.Presentador;

public interface Interface_PresentadorL {
    void login(String usuario, String pass);

    void acceso(String miusuario,String foto);
}
