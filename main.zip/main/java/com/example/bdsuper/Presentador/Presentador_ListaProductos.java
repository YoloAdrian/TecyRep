package com.example.bdsuper.Presentador;

import com.example.bdsuper.Modelo.Adaptador;
import com.example.bdsuper.Modelo.Modelo_listaproductos;
import com.example.bdsuper.Vista.Principal;

public class Presentador_ListaProductos {
    Principal V;
    Modelo_listaproductos M;
    public Presentador_ListaProductos(Principal V){
        this.V = V;
        M=new Modelo_listaproductos(this);
    }
    public void cargarlistaproductos(Adaptador AdaptadorRecycler){
        V.cargarlistaproductos(AdaptadorRecycler);
    }

    //buscar
    

}
