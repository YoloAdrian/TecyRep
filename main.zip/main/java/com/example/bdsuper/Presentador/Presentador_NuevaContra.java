package com.example.bdsuper.Presentador;

import com.example.bdsuper.Modelo.InterfaceModelo_NC;
import com.example.bdsuper.Modelo.InterfaceModelo_RC;
import com.example.bdsuper.Modelo.ModeloNuevaContra;
import com.example.bdsuper.Vista.NuevaContra;

public class Presentador_NuevaContra {

    NuevaContra V;
    InterfaceModelo_NC M;


    public Presentador_NuevaContra(NuevaContra V) {
        this.V = V;
        M = new ModeloNuevaContra(this);
    }

    public void actualizarContrasena(String correo, String nuevaContrasena) {
        M.actualizarContrasenaM(correo, nuevaContrasena);
    }

    public void contrasenaActualizada() {
        V.mostrarExito("Contraseña actualizada correctamente.");
    }

    public void errorAlActualizar(String error) {
        V.mostrarError(error);
    }

}
