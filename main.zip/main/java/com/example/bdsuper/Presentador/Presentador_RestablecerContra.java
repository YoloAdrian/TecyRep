package com.example.bdsuper.Presentador;

import android.util.Log;
import android.widget.Toast;

import com.example.bdsuper.Modelo.InterfaceModelo_RC;
import com.example.bdsuper.Modelo.ModeloRestablecerContra;
import com.example.bdsuper.Vista.Interface_RestablecerContra;
import com.example.bdsuper.Vista.RestablecerContra;

public class Presentador_RestablecerContra {
    RestablecerContra V;
    InterfaceModelo_RC M;

    public Presentador_RestablecerContra(RestablecerContra V) {
        this.V = V;
        M = new ModeloRestablecerContra(this);
    }




    public void obtenerPregunta(String correo) {
        M.obtenerPreguntaM(correo);
    }

    public void mostrarPregunta(String pregunta) {
        V.mostrarPregunta(pregunta);
    }

    public void validarRespuesta(String correo, String respuesta) {
        M.validarRespuesta(correo, respuesta);
    }

    public void respuestaCorrecta() {
        V.irANuevaContra();
    }

    public void respuestaIncorrecta() {
        V.mostrarError("La respuesta es incorrecta.");
    }

}
